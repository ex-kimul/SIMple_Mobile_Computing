LOGIN EXAMPLE WITH DATABASE SQLITE

This project with Scalable app structure. You can use this project structure for other application.
File database show in folder login/data/flutter.db, you can try edit the database for try this application.
Visit my Site https://camellabs.com/

![Login UI Flutter](https://raw.githubusercontent.com/eccosuprastyo/flutter/master/login/screen-login.png)
